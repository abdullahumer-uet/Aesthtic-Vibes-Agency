import { useRef, useLayoutEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ArrowRight, Sticker } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

interface StickerSectionProps {
  className?: string;
}

const StickerSection = ({ className = '' }: StickerSectionProps) => {
  const sectionRef = useRef<HTMLDivElement>(null);
  const leftCardRef = useRef<HTMLDivElement>(null);
  const rightCardRef = useRef<HTMLDivElement>(null);
  const headlineRef = useRef<HTMLHeadingElement>(null);
  const bodyRef = useRef<HTMLParagraphElement>(null);
  const ctaRef = useRef<HTMLDivElement>(null);

  useLayoutEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const ctx = gsap.context(() => {
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: section,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.6,
        }
      });

      // ENTRANCE (0%-30%)
      scrollTl.fromTo(
        leftCardRef.current,
        { x: '-60vw', rotateY: 50, scale: 0.85, opacity: 0 },
        { x: 0, rotateY: 0, scale: 1, opacity: 1, ease: 'none' },
        0
      );

      scrollTl.fromTo(
        rightCardRef.current,
        { x: '60vw', rotateY: -50, scale: 0.85, opacity: 0 },
        { x: 0, rotateY: 0, scale: 1, opacity: 1, ease: 'none' },
        0
      );

      // Headline words animation
      if (headlineRef.current) {
        scrollTl.fromTo(
          headlineRef.current,
          { y: 22, rotateX: 40, opacity: 0 },
          { y: 0, rotateX: 0, opacity: 1, ease: 'none' },
          0.1
        );
      }

      scrollTl.fromTo(
        bodyRef.current,
        { y: 20, opacity: 0 },
        { y: 0, opacity: 1, ease: 'none' },
        0.15
      );

      scrollTl.fromTo(
        ctaRef.current,
        { y: 20, opacity: 0 },
        { y: 0, opacity: 1, ease: 'none' },
        0.2
      );

      // SETTLE (30%-70%): Hold with wobble animation on sticker card

      // EXIT (70%-100%)
      scrollTl.fromTo(
        leftCardRef.current,
        { x: 0, rotateY: 0, opacity: 1 },
        { x: '-55vw', rotateY: 28, opacity: 0, ease: 'power2.in' },
        0.70
      );

      scrollTl.fromTo(
        rightCardRef.current,
        { x: 0, rotateY: 0, opacity: 1 },
        { x: '55vw', rotateY: -28, opacity: 0, ease: 'power2.in' },
        0.70
      );

      // Wobble animation during settle
      gsap.to(leftCardRef.current, {
        rotateZ: 1.5,
        duration: 4,
        ease: 'sine.inOut',
        yoyo: true,
        repeat: -1
      });
    }, section);

    return () => ctx.revert();
  }, []);

  return (
    <section 
      ref={sectionRef} 
      className={`section-pinned bg-[#070A12] ${className}`}
      style={{ perspective: '1200px' }}
    >
      <div className="relative w-full h-full flex items-center justify-center px-6 lg:px-0">
        {/* Left Sticker Card */}
        <div
          ref={leftCardRef}
          className="absolute left-[7vw] top-[14vh] w-[42vw] h-[72vh] ava-card will-change-transform hidden lg:block"
          style={{ transformStyle: 'preserve-3d' }}
        >
          <img
            src="/sticker_pack_flatlay.jpg"
            alt="Sticker packs"
            className="w-full h-full object-cover"
          />
        </div>

        {/* Right Info Card */}
        <div
          ref={rightCardRef}
          className="absolute left-[51vw] top-[14vh] w-[42vw] h-[72vh] ava-card bg-[#070A12]/90 backdrop-blur-sm flex flex-col justify-center p-8 lg:p-12 will-change-transform"
          style={{ transformStyle: 'preserve-3d' }}
        >
          <div className="flex items-center gap-2 mb-6">
            <Sticker className="w-5 h-5 text-[#B9A0FF]" />
            <span className="font-mono text-sm text-[#B9A0FF] tracking-wider uppercase">Fun & Expressive</span>
          </div>

          <h2
            ref={headlineRef}
            className="font-display text-4xl lg:text-5xl xl:text-6xl font-black text-[#F4F6FF] leading-tight mb-6"
            style={{ transformStyle: 'preserve-3d' }}
          >
            STICKER<br />PACKS
          </h2>

          <p
            ref={bodyRef}
            className="text-base lg:text-lg text-[#A7B0C8] max-w-md mb-8 leading-relaxed"
          >
            Laptop. Water bottle. Sketchbook. Make everything yours with matte-finish stickers that actually stick. Express yourself everywhere.
          </p>

          <div ref={ctaRef} className="flex items-center gap-6">
            <button className="btn-primary flex items-center gap-2">
              Shop Stickers
              <ArrowRight className="w-4 h-4" />
            </button>
            <span className="text-sm text-[#A7B0C8]">From $8</span>
          </div>
        </div>

        {/* Mobile layout */}
        <div className="lg:hidden flex flex-col gap-6 w-full max-w-sm px-4">
          <div className="ava-card overflow-hidden">
            <img
              src="/sticker_pack_flatlay.jpg"
              alt="Sticker packs"
              className="w-full h-64 object-cover"
            />
          </div>
          <div className="text-center">
            <h2 className="font-display text-3xl font-black text-[#F4F6FF] mb-4">
              STICKER PACKS
            </h2>
            <p className="text-sm text-[#A7B0C8] mb-6">
              Make everything yours with matte-finish stickers that actually stick.
            </p>
            <button className="btn-primary flex items-center gap-2 mx-auto">
              Shop Stickers
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default StickerSection;
