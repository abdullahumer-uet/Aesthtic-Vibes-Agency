import { useRef, useLayoutEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ArrowRight } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

interface FeaturedSectionProps {
  className?: string;
}

const FeaturedSection = ({ className = '' }: FeaturedSectionProps) => {
  const sectionRef = useRef<HTMLDivElement>(null);
  const cardRef = useRef<HTMLDivElement>(null);
  const imageRef = useRef<HTMLImageElement>(null);
  const titleRef = useRef<HTMLHeadingElement>(null);
  const subtitleRef = useRef<HTMLParagraphElement>(null);
  const ctaRef = useRef<HTMLButtonElement>(null);

  useLayoutEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const ctx = gsap.context(() => {
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: section,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.6,
        }
      });

      // ENTRANCE (0%-30%)
      scrollTl.fromTo(
        cardRef.current,
        { y: '100vh', rotateX: 45, scale: 0.88, opacity: 0 },
        { y: 0, rotateX: 0, scale: 1, opacity: 1, ease: 'none' },
        0
      );

      scrollTl.fromTo(
        titleRef.current,
        { x: '-18vw', opacity: 0 },
        { x: 0, opacity: 1, ease: 'none' },
        0.1
      );

      scrollTl.fromTo(
        subtitleRef.current,
        { x: '-18vw', opacity: 0 },
        { x: 0, opacity: 1, ease: 'none' },
        0.15
      );

      scrollTl.fromTo(
        ctaRef.current,
        { x: '18vw', opacity: 0 },
        { x: 0, opacity: 1, ease: 'none' },
        0.2
      );

      // SETTLE (30%-70%): Hold with subtle parallax
      if (imageRef.current) {
        scrollTl.to(
          imageRef.current,
          { y: -12, ease: 'none' },
          0.3
        );
      }

      // EXIT (70%-100%)
      scrollTl.fromTo(
        cardRef.current,
        { y: 0, rotateX: 0, scale: 1, opacity: 1 },
        { y: '-35vh', rotateX: -18, scale: 0.95, opacity: 0, ease: 'power2.in' },
        0.70
      );

      scrollTl.fromTo(
        [titleRef.current, subtitleRef.current, ctaRef.current],
        { opacity: 1 },
        { opacity: 0, ease: 'power2.in' },
        0.75
      );
    }, section);

    return () => ctx.revert();
  }, []);

  return (
    <section 
      ref={sectionRef} 
      className={`section-pinned bg-[#070A12] ${className}`}
      style={{ perspective: '1200px' }}
    >
      <div className="relative w-full h-full flex items-center justify-center px-6 lg:px-0">
        {/* Wide Featured Card */}
        <div
          ref={cardRef}
          className="absolute left-[7vw] top-[14vh] w-[86vw] h-[72vh] ava-card will-change-transform overflow-hidden"
          style={{ transformStyle: 'preserve-3d' }}
        >
          <img
            src="/featured_collection_room.jpg"
            alt="Featured collection"
            className="w-full h-full object-cover"
          />
          
          {/* Gradient overlay */}
          <div className="absolute inset-0 bg-gradient-to-t from-[#070A12]/90 via-[#070A12]/30 to-transparent" />
          
          {/* Content */}
          <div className="absolute bottom-0 left-0 right-0 p-8 lg:p-16">
            <div className="flex flex-col lg:flex-row lg:items-end lg:justify-between gap-6">
              <div>
                <h2
                  ref={titleRef}
                  className="font-display text-3xl sm:text-4xl lg:text-5xl xl:text-6xl font-black text-[#F4F6FF] leading-tight mb-3"
                >
                  FEATURED<br />COLLECTION
                </h2>
                <p
                  ref={subtitleRef}
                  className="text-base lg:text-lg text-[#A7B0C8] max-w-md"
                >
                  A hand-picked set for clean, modern spaces. Elevate your interior with our curated selection.
                </p>
              </div>
              
              <button
                ref={ctaRef}
                className="btn-primary flex items-center gap-2 self-start lg:self-auto"
              >
                View the Edit
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default FeaturedSection;
