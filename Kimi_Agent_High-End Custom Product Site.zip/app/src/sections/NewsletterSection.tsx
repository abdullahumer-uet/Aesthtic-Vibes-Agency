import { useRef, useLayoutEffect, useState } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Mail, Instagram, Twitter, Facebook, Send, Sparkles } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

interface NewsletterSectionProps {
  className?: string;
}

const NewsletterSection = ({ className = '' }: NewsletterSectionProps) => {
  const sectionRef = useRef<HTMLDivElement>(null);
  const cardRef = useRef<HTMLDivElement>(null);
  const headlineRef = useRef<HTMLHeadingElement>(null);
  const formRef = useRef<HTMLFormElement>(null);
  const footerRef = useRef<HTMLDivElement>(null);
  
  const [email, setEmail] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);

  useLayoutEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const ctx = gsap.context(() => {
      // Card reveal animation
      gsap.fromTo(
        cardRef.current,
        { y: '8vh', rotateX: 18, scale: 0.98, opacity: 0 },
        {
          y: 0,
          rotateX: 0,
          scale: 1,
          opacity: 1,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: cardRef.current,
            start: 'top 80%',
            end: 'top 45%',
            scrub: true,
          }
        }
      );

      // Headline animation
      gsap.fromTo(
        headlineRef.current,
        { y: 30, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: headlineRef.current,
            start: 'top 85%',
            end: 'top 55%',
            scrub: true,
          }
        }
      );

      // Form animation
      gsap.fromTo(
        formRef.current,
        { y: 20, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: formRef.current,
            start: 'top 85%',
            end: 'top 60%',
            scrub: true,
          }
        }
      );

      // Footer columns animation
      const footerColumns = footerRef.current?.querySelectorAll('.footer-column');
      if (footerColumns) {
        gsap.fromTo(
          footerColumns,
          { y: 24, opacity: 0 },
          {
            y: 0,
            opacity: 1,
            stagger: 0.1,
            ease: 'power2.out',
            scrollTrigger: {
              trigger: footerRef.current,
              start: 'top 90%',
              end: 'top 65%',
              scrub: true,
            }
          }
        );
      }
    }, section);

    return () => ctx.revert();
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (email) {
      setIsSubmitted(true);
      setEmail('');
    }
  };

  const footerLinks = {
    Shop: ['Posters', 'Stickers', 'Printables', 'Bundles'],
    Support: ['Shipping', 'Returns', 'FAQ', 'Contact'],
    Company: ['About', 'Careers', 'Sustainability'],
    Social: [
      { name: 'Instagram', icon: Instagram },
      { name: 'TikTok', icon: Twitter },
      { name: 'Pinterest', icon: Facebook },
    ],
  };

  return (
    <section 
      ref={sectionRef}
      id="newsletter"
      className={`relative bg-[#070A12] py-20 lg:py-32 ${className}`}
    >
      <div className="max-w-7xl mx-auto px-6 lg:px-12">
        {/* Newsletter Card */}
        <div
          ref={cardRef}
          className="ava-card bg-gradient-to-br from-[#1a1f2e] to-[#0d1119] p-8 lg:p-16 mb-16"
          style={{ perspective: '1000px' }}
        >
          <div className="text-center max-w-2xl mx-auto">
            <div className="flex items-center justify-center gap-2 mb-4">
              <Sparkles className="w-5 h-5 text-[#B9A0FF]" />
              <span className="font-mono text-sm text-[#B9A0FF] tracking-wider uppercase">Join the Community</span>
            </div>

            <h2
              ref={headlineRef}
              className="font-display text-3xl sm:text-4xl lg:text-5xl font-black text-[#F4F6FF] mb-4"
            >
              GET THE DROP
            </h2>

            <p className="text-base lg:text-lg text-[#A7B0C8] mb-8">
              New collections, printable freebies, and sticker releases—straight to your inbox.
            </p>

            {isSubmitted ? (
              <div className="flex items-center justify-center gap-2 text-[#B9A0FF]">
                <Sparkles className="w-5 h-5" />
                <span className="font-medium">You're on the list! Welcome to AVA.</span>
              </div>
            ) : (
              <form
                ref={formRef}
                onSubmit={handleSubmit}
                className="flex flex-col sm:flex-row gap-4 max-w-md mx-auto"
              >
                <div className="relative flex-1">
                  <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#A7B0C8]" />
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="you@example.com"
                    className="w-full pl-12 pr-4 py-3 bg-[#070A12] border border-[#1a1f2e] rounded-full text-[#F4F6FF] placeholder:text-[#A7B0C8] focus:outline-none focus:border-[#B9A0FF] transition-colors"
                    required
                  />
                </div>
                <button
                  type="submit"
                  className="btn-primary flex items-center justify-center gap-2"
                >
                  Subscribe
                  <Send className="w-4 h-4" />
                </button>
              </form>
            )}

            <p className="text-xs text-[#A7B0C8] mt-4">
              No spam. Unsubscribe anytime.
            </p>
          </div>
        </div>

        {/* Footer */}
        <div
          ref={footerRef}
          className="grid grid-cols-2 md:grid-cols-4 gap-8 lg:gap-12 pt-12 border-t border-[#1a1f2e]"
        >
          {Object.entries(footerLinks).map(([category, links]) => (
            <div key={category} className="footer-column">
              <h3 className="font-display text-sm font-bold text-[#F4F6FF] uppercase tracking-wider mb-4">
                {category}
              </h3>
              <ul className="space-y-2">
                {links.map((link: any) => (
                  <li key={typeof link === 'string' ? link : link.name}>
                    <button className="text-sm text-[#A7B0C8] hover:text-[#B9A0FF] transition-colors flex items-center gap-2">
                      {typeof link === 'string' ? (
                        link
                      ) : (
                        <>
                          <link.icon className="w-4 h-4" />
                          {link.name}
                        </>
                      )}
                    </button>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Bottom bar */}
        <div className="flex flex-col md:flex-row items-center justify-between gap-4 pt-12 mt-12 border-t border-[#1a1f2e]">
          <div className="flex items-center gap-2">
            <span className="font-display text-xl font-black text-[#F4F6FF]">AVA</span>
            <span className="text-sm text-[#A7B0C8]">Aesthetic Vibes Agency</span>
          </div>
          
          <div className="flex items-center gap-6 text-sm text-[#A7B0C8]">
            <button className="hover:text-[#B9A0FF] transition-colors">Privacy Policy</button>
            <button className="hover:text-[#B9A0FF] transition-colors">Terms of Service</button>
            <button className="hover:text-[#B9A0FF] transition-colors">Disclaimer</button>
          </div>
          
          <p className="text-sm text-[#A7B0C8]">
            © 2024 AVA. All rights reserved.
          </p>
        </div>
      </div>
    </section>
  );
};

export default NewsletterSection;
