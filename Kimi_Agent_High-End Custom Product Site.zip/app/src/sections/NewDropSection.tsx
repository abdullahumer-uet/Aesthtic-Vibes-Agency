import { useRef, useLayoutEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ArrowRight, Zap } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

interface NewDropSectionProps {
  className?: string;
}

const NewDropSection = ({ className = '' }: NewDropSectionProps) => {
  const sectionRef = useRef<HTMLDivElement>(null);
  const bannerRef = useRef<HTMLDivElement>(null);
  const imageRef = useRef<HTMLImageElement>(null);
  const headlineRef = useRef<HTMLHeadingElement>(null);
  const subheadlineRef = useRef<HTMLParagraphElement>(null);
  const ctaRef = useRef<HTMLButtonElement>(null);

  useLayoutEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const ctx = gsap.context(() => {
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: section,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.6,
        }
      });

      // ENTRANCE (0%-30%)
      scrollTl.fromTo(
        bannerRef.current,
        { y: '110vh', scale: 0.92, opacity: 0 },
        { y: 0, scale: 1, opacity: 1, ease: 'none' },
        0
      );

      scrollTl.fromTo(
        headlineRef.current,
        { y: '18vh', opacity: 0 },
        { y: 0, opacity: 1, ease: 'none' },
        0.1
      );

      scrollTl.fromTo(
        subheadlineRef.current,
        { y: '12vh', opacity: 0 },
        { y: 0, opacity: 1, ease: 'none' },
        0.15
      );

      scrollTl.fromTo(
        ctaRef.current,
        { scale: 0.85, opacity: 0 },
        { scale: 1, opacity: 1, ease: 'none' },
        0.2
      );

      // SETTLE (30%-70%): Hold with subtle parallax
      if (imageRef.current) {
        scrollTl.to(
          imageRef.current,
          { y: -16, ease: 'none' },
          0.3
        );
      }

      // EXIT (70%-100%)
      scrollTl.fromTo(
        bannerRef.current,
        { x: 0, rotateY: 0, scale: 1, opacity: 1 },
        { x: '-18vw', rotateY: 18, scale: 0.95, opacity: 0, ease: 'power2.in' },
        0.70
      );

      scrollTl.fromTo(
        [headlineRef.current, subheadlineRef.current, ctaRef.current],
        { opacity: 1 },
        { opacity: 0, ease: 'power2.in' },
        0.75
      );
    }, section);

    return () => ctx.revert();
  }, []);

  return (
    <section 
      ref={sectionRef} 
      className={`section-pinned bg-[#070A12] ${className}`}
      style={{ perspective: '1200px' }}
    >
      <div className="relative w-full h-full flex items-center justify-center">
        {/* Full-bleed Banner Card */}
        <div
          ref={bannerRef}
          className="absolute left-0 top-[10vh] w-full h-[80vh] overflow-hidden will-change-transform"
          style={{ transformStyle: 'preserve-3d' }}
        >
          <img
            ref={imageRef}
            src="/new_drop_banner.jpg"
            alt="New drop"
            className="w-full h-full object-cover"
          />
          
          {/* Dark overlay */}
          <div className="absolute inset-0 bg-[#070A12]/60" />
          
          {/* Content - Centered */}
          <div className="absolute inset-0 flex flex-col items-center justify-center text-center px-6">
            <div className="flex items-center gap-2 mb-4">
              <Zap className="w-5 h-5 text-[#B9A0FF]" />
              <span className="font-mono text-sm text-[#B9A0FF] tracking-wider uppercase">Limited Edition</span>
            </div>
            
            <h2
              ref={headlineRef}
              className="font-display text-5xl sm:text-6xl lg:text-7xl xl:text-8xl font-black text-[#F4F6FF] leading-none mb-6"
            >
              NEW DROP
            </h2>
            
            <p
              ref={subheadlineRef}
              className="text-base lg:text-lg text-[#A7B0C8] max-w-lg mb-8"
            >
              Limited prints + sticker packs—once they're gone, they're gone. Don't miss out on this exclusive collection.
            </p>
            
            <button
              ref={ctaRef}
              className="btn-primary flex items-center gap-2 text-lg"
            >
              Grab Yours
              <ArrowRight className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default NewDropSection;
