import { useRef, useLayoutEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ArrowRight } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

interface BestsellersSectionProps {
  className?: string;
}

const BestsellersSection = ({ className = '' }: BestsellersSectionProps) => {
  const sectionRef = useRef<HTMLDivElement>(null);
  const labelRef = useRef<HTMLHeadingElement>(null);
  const card1Ref = useRef<HTMLDivElement>(null);
  const card2Ref = useRef<HTMLDivElement>(null);
  const card3Ref = useRef<HTMLDivElement>(null);

  useLayoutEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const ctx = gsap.context(() => {
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: section,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.6,
        }
      });

      // ENTRANCE (0%-30%)
      scrollTl.fromTo(
        card1Ref.current,
        { x: '-60vw', rotateY: 50, scale: 0.85, opacity: 0 },
        { x: 0, rotateY: 0, scale: 1, opacity: 1, ease: 'none' },
        0
      );

      scrollTl.fromTo(
        card3Ref.current,
        { x: '60vw', rotateY: -50, scale: 0.85, opacity: 0 },
        { x: 0, rotateY: 0, scale: 1, opacity: 1, ease: 'none' },
        0
      );

      scrollTl.fromTo(
        card2Ref.current,
        { y: '90vh', rotateX: 40, scale: 0.9, opacity: 0 },
        { y: 0, rotateX: 0, scale: 1, opacity: 1, ease: 'none' },
        0
      );

      scrollTl.fromTo(
        labelRef.current,
        { opacity: 0, y: -30 },
        { opacity: 1, y: 0, ease: 'none' },
        0.1
      );

      // SETTLE (30%-70%): Hold with subtle float

      // EXIT (70%-100%)
      scrollTl.fromTo(
        card1Ref.current,
        { x: 0, scale: 1, opacity: 1 },
        { x: '-30vw', scale: 0.96, opacity: 0, ease: 'power2.in' },
        0.70
      );

      scrollTl.fromTo(
        card3Ref.current,
        { x: 0, scale: 1, opacity: 1 },
        { x: '30vw', scale: 0.96, opacity: 0, ease: 'power2.in' },
        0.70
      );

      scrollTl.fromTo(
        card2Ref.current,
        { y: 0, scale: 1, opacity: 1 },
        { y: '30vh', scale: 0.96, opacity: 0, ease: 'power2.in' },
        0.70
      );

      scrollTl.fromTo(
        labelRef.current,
        { opacity: 1 },
        { opacity: 0, ease: 'power2.in' },
        0.75
      );

      // Ambient float
      gsap.to(card1Ref.current, {
        y: '+=8',
        duration: 3,
        ease: 'sine.inOut',
        yoyo: true,
        repeat: -1
      });

      gsap.to(card2Ref.current, {
        y: '+=8',
        duration: 3,
        ease: 'sine.inOut',
        yoyo: true,
        repeat: -1,
        delay: 0.3
      });

      gsap.to(card3Ref.current, {
        y: '+=8',
        duration: 3,
        ease: 'sine.inOut',
        yoyo: true,
        repeat: -1,
        delay: 0.6
      });
    }, section);

    return () => ctx.revert();
  }, []);

  const products = [
    { ref: card1Ref, image: '/bestseller_1_botanical.jpg', name: 'Midnight Botanical', price: 'From $18' },
    { ref: card2Ref, image: '/bestseller_2_geometry.jpg', name: 'Soft Geometry', price: 'From $16' },
    { ref: card3Ref, image: '/bestseller_3_neon_flora.jpg', name: 'Neon Flora', price: 'From $20' },
  ];

  return (
    <section 
      ref={sectionRef}
      id="bestsellers"
      className={`section-pinned bg-[#070A12] ${className}`}
      style={{ perspective: '1200px' }}
    >
      {/* Label */}
      <div className="absolute top-[7vh] left-[7vw] flex items-center gap-4">
        <h2
          ref={labelRef}
          className="font-display text-2xl lg:text-3xl font-black text-[#F4F6FF] tracking-tight"
        >
          BESTSELLERS
        </h2>
        <button className="text-sm text-[#B9A0FF] hover:text-[#F4F6FF] flex items-center gap-1 transition-colors">
          Shop all <ArrowRight className="w-4 h-4" />
        </button>
      </div>

      {/* Cards */}
      <div className="relative w-full h-full flex items-center justify-center px-4 lg:px-0">
        {products.map((product, index) => (
          <div
            key={index}
            ref={product.ref}
            className={`absolute ${
              index === 0 ? 'left-[7vw]' : index === 1 ? 'left-[37vw]' : 'left-[67vw]'
            } top-[14vh] w-[26vw] h-[72vh] ava-card-sm will-change-transform hidden lg:block cursor-pointer group`}
            style={{ transformStyle: 'preserve-3d' }}
          >
            <div className="relative w-full h-full image-scrim overflow-hidden">
              <img
                src={product.image}
                alt={product.name}
                className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
              />
              {/* Product info */}
              <div className="absolute bottom-6 left-6 right-6">
                <h3 className="font-display text-lg font-bold text-[#F4F6FF] mb-1">
                  {product.name}
                </h3>
                <p className="text-sm text-[#A7B0C8]">
                  {product.price}
                </p>
              </div>
              {/* Hover overlay */}
              <div className="absolute inset-0 bg-[#B9A0FF]/0 group-hover:bg-[#B9A0FF]/10 transition-colors duration-300" />
            </div>
          </div>
        ))}

        {/* Mobile cards */}
        <div className="lg:hidden flex flex-col gap-4 w-full max-w-sm px-4 mt-16">
          {products.map((product, index) => (
            <div key={index} className="ava-card-sm overflow-hidden">
              <div className="relative h-64 image-scrim">
                <img
                  src={product.image}
                  alt={product.name}
                  className="w-full h-full object-cover"
                />
                <div className="absolute bottom-4 left-4">
                  <h3 className="font-display text-lg font-bold text-[#F4F6FF] mb-1">
                    {product.name}
                  </h3>
                  <p className="text-sm text-[#A7B0C8]">{product.price}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default BestsellersSection;
