import { useRef, useLayoutEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ArrowRight } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

interface AestheticSectionProps {
  className?: string;
}

const AestheticSection = ({ className = '' }: AestheticSectionProps) => {
  const sectionRef = useRef<HTMLDivElement>(null);
  const titleRef = useRef<HTMLHeadingElement>(null);
  const card1Ref = useRef<HTMLDivElement>(null);
  const card2Ref = useRef<HTMLDivElement>(null);
  const card3Ref = useRef<HTMLDivElement>(null);

  useLayoutEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const ctx = gsap.context(() => {
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: section,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.6,
        }
      });

      // ENTRANCE (0%-30%)
      scrollTl.fromTo(
        card1Ref.current,
        { x: '-60vw', rotateY: 55, scale: 0.85, opacity: 0 },
        { x: 0, rotateY: 0, scale: 1, opacity: 1, ease: 'none' },
        0
      );

      scrollTl.fromTo(
        card3Ref.current,
        { x: '60vw', rotateY: -55, scale: 0.85, opacity: 0 },
        { x: 0, rotateY: 0, scale: 1, opacity: 1, ease: 'none' },
        0
      );

      scrollTl.fromTo(
        card2Ref.current,
        { y: '90vh', rotateX: 40, scale: 0.9, opacity: 0 },
        { y: 0, rotateX: 0, scale: 1, opacity: 1, ease: 'none' },
        0
      );

      scrollTl.fromTo(
        titleRef.current,
        { opacity: 0, y: '-4vh' },
        { opacity: 1, y: 0, ease: 'none' },
        0.1
      );

      // SETTLE (30%-70%): Hold with subtle float

      // EXIT (70%-100%)
      scrollTl.fromTo(
        [card1Ref.current, card2Ref.current, card3Ref.current],
        { y: 0, rotateX: 0, scale: 1, opacity: 1 },
        { y: '40vh', rotateX: -18, scale: 0.94, opacity: 0, ease: 'power2.in' },
        0.70
      );

      scrollTl.fromTo(
        titleRef.current,
        { opacity: 1 },
        { opacity: 0, ease: 'power2.in' },
        0.75
      );

      // Ambient float
      gsap.to(card1Ref.current, {
        y: '+=10',
        duration: 3.5,
        ease: 'sine.inOut',
        yoyo: true,
        repeat: -1
      });

      gsap.to(card2Ref.current, {
        y: '+=10',
        duration: 3.5,
        ease: 'sine.inOut',
        yoyo: true,
        repeat: -1,
        delay: 0.5
      });

      gsap.to(card3Ref.current, {
        y: '+=10',
        duration: 3.5,
        ease: 'sine.inOut',
        yoyo: true,
        repeat: -1,
        delay: 1
      });
    }, section);

    return () => ctx.revert();
  }, []);

  const aesthetics = [
    { 
      ref: card1Ref, 
      image: '/aesthetic_dark_academia.jpg', 
      name: 'DARK ACADEMIA',
      description: 'Intellectual, moody designs with vintage charm'
    },
    { 
      ref: card2Ref, 
      image: '/aesthetic_vaporwave.jpg', 
      name: 'VAPORWAVE',
      description: 'Neon dreams and retro-futuristic vibes'
    },
    { 
      ref: card3Ref, 
      image: '/aesthetic_cozy_max.jpg', 
      name: 'COZY MAXIMALISM',
      description: 'Layered textures and warm botanical elements'
    },
  ];

  return (
    <section 
      ref={sectionRef}
      id="aesthetics"
      className={`section-pinned bg-[#6B2C6B] ${className}`}
      style={{ perspective: '1200px' }}
    >
      {/* Title */}
      <h2
        ref={titleRef}
        className="absolute top-[6vh] left-1/2 -translate-x-1/2 font-display text-2xl lg:text-3xl font-black text-[#F4F6FF] tracking-tight text-center"
      >
        SHOP BY AESTHETIC
      </h2>

      {/* Cards */}
      <div className="relative w-full h-full flex items-center justify-center px-4 lg:px-0">
        {aesthetics.map((aesthetic, index) => (
          <div
            key={index}
            ref={aesthetic.ref}
            className={`absolute ${
              index === 0 ? 'left-[7vw]' : index === 1 ? 'left-[37vw]' : 'left-[67vw]'
            } top-[14vh] w-[26vw] h-[72vh] ava-card-sm will-change-transform hidden lg:block cursor-pointer group`}
            style={{ transformStyle: 'preserve-3d' }}
          >
            <div className="relative w-full h-full image-scrim overflow-hidden">
              <img
                src={aesthetic.image}
                alt={aesthetic.name}
                className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
              />
              {/* Gradient overlay */}
              <div className="absolute inset-0 bg-gradient-to-t from-[#070A12]/90 via-transparent to-transparent" />
              
              {/* Content */}
              <div className="absolute bottom-6 left-6 right-6">
                <h3 className="font-display text-xl font-black text-[#F4F6FF] mb-2 tracking-tight">
                  {aesthetic.name}
                </h3>
                <p className="text-sm text-[#A7B0C8] mb-4">
                  {aesthetic.description}
                </p>
                <button className="text-sm text-[#B9A0FF] hover:text-[#F4F6FF] flex items-center gap-1 transition-colors">
                  Explore <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        ))}

        {/* Mobile cards */}
        <div className="lg:hidden flex flex-col gap-4 w-full max-w-sm px-4 mt-16">
          {aesthetics.map((aesthetic, index) => (
            <div key={index} className="ava-card-sm overflow-hidden">
              <div className="relative h-64 image-scrim">
                <img
                  src={aesthetic.image}
                  alt={aesthetic.name}
                  className="w-full h-full object-cover"
                />
                <div className="absolute bottom-4 left-4 right-4">
                  <h3 className="font-display text-lg font-black text-[#F4F6FF] mb-1">
                    {aesthetic.name}
                  </h3>
                  <p className="text-sm text-[#A7B0C8] mb-2">{aesthetic.description}</p>
                  <button className="text-sm text-[#B9A0FF] flex items-center gap-1">
                    Explore <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default AestheticSection;
