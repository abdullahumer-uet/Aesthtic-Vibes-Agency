import { useEffect, useRef, useLayoutEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ArrowRight, Sparkles } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

interface HeroSectionProps {
  className?: string;
}

const HeroSection = ({ className = '' }: HeroSectionProps) => {
  const sectionRef = useRef<HTMLDivElement>(null);
  const portraitRef = useRef<HTMLDivElement>(null);
  const textCardRef = useRef<HTMLDivElement>(null);
  const headlineRef = useRef<HTMLHeadingElement>(null);
  const subheadlineRef = useRef<HTMLParagraphElement>(null);
  const ctaRef = useRef<HTMLDivElement>(null);
  const badgeRef = useRef<HTMLDivElement>(null);

  // Auto-play entrance animation on load
  useEffect(() => {
    const ctx = gsap.context(() => {
      const tl = gsap.timeline({ defaults: { ease: 'power2.out' } });

      // Portrait card entrance
      tl.fromTo(
        portraitRef.current,
        { opacity: 0, x: '-12vw', rotateY: 18, scale: 0.96 },
        { opacity: 1, x: 0, rotateY: 0, scale: 1, duration: 1 },
        0
      );

      // Text card entrance
      tl.fromTo(
        textCardRef.current,
        { opacity: 0, x: '12vw', rotateY: -18, scale: 0.96 },
        { opacity: 1, x: 0, rotateY: 0, scale: 1, duration: 1 },
        0
      );

      // Headline words animation
      if (headlineRef.current) {
        const words = headlineRef.current.querySelectorAll('.word');
        tl.fromTo(
          words,
          { opacity: 0, y: 24, rotateX: 35 },
          { opacity: 1, y: 0, rotateX: 0, duration: 0.6, stagger: 0.05 },
          0.3
        );
      }

      // Subheadline
      tl.fromTo(
        subheadlineRef.current,
        { opacity: 0, y: 18 },
        { opacity: 1, y: 0, duration: 0.6 },
        0.5
      );

      // CTAs
      tl.fromTo(
        ctaRef.current?.children || [],
        { opacity: 0, y: 18 },
        { opacity: 1, y: 0, duration: 0.5, stagger: 0.08 },
        0.6
      );

      // Badge
      tl.fromTo(
        badgeRef.current,
        { opacity: 0, scale: 0.8 },
        { opacity: 1, scale: 1, duration: 0.5 },
        0.7
      );
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  // Scroll-driven exit animation
  useLayoutEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const ctx = gsap.context(() => {
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: section,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.6,
          onLeaveBack: () => {
            // Reset all elements to visible when scrolling back
            gsap.set([portraitRef.current, textCardRef.current], { 
              opacity: 1, x: 0, rotateY: 0, scale: 1 
            });
            gsap.set([headlineRef.current, subheadlineRef.current, ctaRef.current, badgeRef.current], { 
              opacity: 1, y: 0 
            });
          }
        }
      });

      // ENTRANCE (0%-30%): Hold position (already animated on load)
      // SETTLE (30%-70%): Hold position

      // EXIT (70%-100%)
      scrollTl.fromTo(
        portraitRef.current,
        { x: 0, rotateY: 0, scale: 1, opacity: 1 },
        { x: '-55vw', rotateY: 28, scale: 0.92, opacity: 0, ease: 'power2.in' },
        0.70
      );

      scrollTl.fromTo(
        textCardRef.current,
        { x: 0, rotateY: 0, scale: 1, opacity: 1 },
        { x: '55vw', rotateY: -28, scale: 0.92, opacity: 0, ease: 'power2.in' },
        0.70
      );

      scrollTl.fromTo(
        [headlineRef.current, subheadlineRef.current],
        { y: 0, opacity: 1 },
        { y: '6vh', opacity: 0, ease: 'power2.in' },
        0.75
      );

      scrollTl.fromTo(
        [ctaRef.current, badgeRef.current],
        { opacity: 1 },
        { opacity: 0, ease: 'power2.in' },
        0.80
      );
    }, section);

    return () => ctx.revert();
  }, []);

  return (
    <section 
      ref={sectionRef} 
      className={`section-pinned bg-[#070A12] ${className}`}
      style={{ perspective: '1200px' }}
    >
      {/* Background vignette */}
      <div className="absolute inset-0 bg-gradient-radial from-transparent via-transparent to-black/60 pointer-events-none" />

      <div className="relative w-full h-full flex items-center justify-center px-6 lg:px-0">
        {/* Left Portrait Card */}
        <div
          ref={portraitRef}
          className="absolute left-[6vw] top-[12vh] w-[42vw] h-[76vh] ava-card will-change-transform hidden lg:block"
          style={{ transformStyle: 'preserve-3d' }}
        >
          <img
            src="/hero_portrait.jpg"
            alt="Aesthetic portrait"
            className="w-full h-full object-cover"
          />
        </div>

        {/* Right Text Card */}
        <div
          ref={textCardRef}
          className="absolute lg:left-[52vw] left-1/2 lg:top-[12vh] top-1/2 lg:-translate-x-0 -translate-x-1/2 lg:-translate-y-0 -translate-y-1/2 
                     lg:w-[42vw] w-[90vw] lg:h-[76vh] h-auto min-h-[60vh] ava-card 
                     bg-[#070A12]/80 backdrop-blur-sm flex flex-col justify-center p-8 lg:p-12 will-change-transform"
          style={{ transformStyle: 'preserve-3d' }}
        >
          {/* Badge */}
          <div
            ref={badgeRef}
            className="absolute top-6 right-6 px-3 py-1 bg-[#B9A0FF] text-[#070A12] text-xs font-mono font-medium tracking-wider rounded-full flex items-center gap-1"
          >
            <Sparkles className="w-3 h-3" />
            NEW DROP
          </div>

          {/* Headline */}
          <h1
            ref={headlineRef}
            className="font-display text-4xl sm:text-5xl lg:text-6xl xl:text-7xl font-black text-[#F4F6FF] leading-[0.95] tracking-tight mb-6"
            style={{ transformStyle: 'preserve-3d' }}
          >
            <span className="word inline-block">CURATE</span>{' '}
            <span className="word inline-block">YOUR</span>{' '}
            <span className="word inline-block text-gradient">VIBE</span>
          </h1>

          {/* Subheadline */}
          <p
            ref={subheadlineRef}
            className="text-base lg:text-lg text-[#A7B0C8] max-w-md mb-8 leading-relaxed"
          >
            Aesthetic prints, posters & stickers—made for your space. Transform your room into a reflection of you.
          </p>

          {/* CTAs */}
          <div ref={ctaRef} className="flex flex-wrap gap-4">
            <button className="btn-primary flex items-center gap-2">
              Shop Bestsellers
              <ArrowRight className="w-4 h-4" />
            </button>
            <button className="btn-secondary">
              Explore Collections
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
