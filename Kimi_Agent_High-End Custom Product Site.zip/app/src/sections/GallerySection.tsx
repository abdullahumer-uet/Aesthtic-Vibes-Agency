import { useRef, useLayoutEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

interface GallerySectionProps {
  className?: string;
}

const GallerySection = ({ className = '' }: GallerySectionProps) => {
  const sectionRef = useRef<HTMLDivElement>(null);
  const cardARef = useRef<HTMLDivElement>(null);
  const cardBRef = useRef<HTMLDivElement>(null);
  const cardCRef = useRef<HTMLDivElement>(null);
  const microcopyRef = useRef<HTMLParagraphElement>(null);

  useLayoutEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const ctx = gsap.context(() => {
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: section,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.6,
        }
      });

      // ENTRANCE (0%-30%)
      scrollTl.fromTo(
        cardARef.current,
        { x: '-60vw', rotateY: 55, scale: 0.85, opacity: 0 },
        { x: 0, rotateY: 0, scale: 1, opacity: 1, ease: 'none' },
        0
      );

      scrollTl.fromTo(
        cardCRef.current,
        { x: '60vw', rotateY: -55, scale: 0.85, opacity: 0 },
        { x: 0, rotateY: 0, scale: 1, opacity: 1, ease: 'none' },
        0
      );

      scrollTl.fromTo(
        cardBRef.current,
        { y: '90vh', rotateX: 40, scale: 0.9, opacity: 0 },
        { y: 0, rotateX: 0, scale: 1, opacity: 1, ease: 'none' },
        0
      );

      scrollTl.fromTo(
        microcopyRef.current,
        { opacity: 0, y: -20 },
        { opacity: 1, y: 0, ease: 'none' },
        0.1
      );

      // SETTLE (30%-70%): Hold position

      // EXIT (70%-100%)
      scrollTl.fromTo(
        cardARef.current,
        { x: 0, opacity: 1 },
        { x: '-40vw', opacity: 0, ease: 'power2.in' },
        0.70
      );

      scrollTl.fromTo(
        cardCRef.current,
        { x: 0, opacity: 1 },
        { x: '40vw', opacity: 0, ease: 'power2.in' },
        0.70
      );

      scrollTl.fromTo(
        cardBRef.current,
        { y: 0, opacity: 1 },
        { y: '40vh', opacity: 0, ease: 'power2.in' },
        0.70
      );

      scrollTl.fromTo(
        microcopyRef.current,
        { opacity: 1 },
        { opacity: 0, ease: 'power2.in' },
        0.75
      );

      // Ambient float animation during settle
      gsap.to(cardARef.current, {
        y: '+=10',
        duration: 3.5,
        ease: 'sine.inOut',
        yoyo: true,
        repeat: -1
      });

      gsap.to(cardBRef.current, {
        y: '+=10',
        duration: 3.5,
        ease: 'sine.inOut',
        yoyo: true,
        repeat: -1,
        delay: 0.5
      });

      gsap.to(cardCRef.current, {
        y: '+=10',
        duration: 3.5,
        ease: 'sine.inOut',
        yoyo: true,
        repeat: -1,
        delay: 1
      });
    }, section);

    return () => ctx.revert();
  }, []);

  const cards = [
    { ref: cardARef, image: '/gallery_plant_print.jpg', caption: 'Moodboard prints' },
    { ref: cardBRef, image: '/gallery_line_art.jpg', caption: 'Minimal lines' },
    { ref: cardCRef, image: '/gallery_portrait_poster.jpg', caption: 'Portrait series' },
  ];

  return (
    <section 
      ref={sectionRef} 
      className={`section-pinned bg-[#070A12] ${className}`}
      style={{ perspective: '1200px' }}
    >
      {/* Microcopy */}
      <p
        ref={microcopyRef}
        className="absolute top-[6vh] left-1/2 -translate-x-1/2 text-sm font-mono text-[#A7B0C8] tracking-wider uppercase"
      >
        Curated by the AVA team—updated weekly
      </p>

      {/* Cards */}
      <div className="relative w-full h-full flex items-center justify-center px-4 lg:px-0">
        {cards.map((card, index) => (
          <div
            key={index}
            ref={card.ref}
            className={`absolute ${
              index === 0 ? 'left-[7vw]' : index === 1 ? 'left-[37vw]' : 'left-[67vw]'
            } top-[14vh] w-[26vw] h-[72vh] ava-card-sm will-change-transform hidden lg:block`}
            style={{ transformStyle: 'preserve-3d' }}
          >
            <div className="relative w-full h-full image-scrim">
              <img
                src={card.image}
                alt={card.caption}
                className="w-full h-full object-cover"
              />
              {/* Caption */}
              <div className="absolute bottom-6 left-6 right-6">
                <span className="px-3 py-1.5 bg-black/50 backdrop-blur-sm text-xs font-mono text-[#F4F6FF] tracking-wider uppercase rounded-full">
                  {card.caption}
                </span>
              </div>
            </div>
          </div>
        ))}

        {/* Mobile cards - stacked */}
        <div className="lg:hidden flex flex-col gap-4 w-full max-w-sm px-4">
          {cards.map((card, index) => (
            <div key={index} className="ava-card-sm overflow-hidden">
              <div className="relative h-64 image-scrim">
                <img
                  src={card.image}
                  alt={card.caption}
                  className="w-full h-full object-cover"
                />
                <div className="absolute bottom-4 left-4">
                  <span className="px-3 py-1.5 bg-black/50 backdrop-blur-sm text-xs font-mono text-[#F4F6FF] tracking-wider uppercase rounded-full">
                    {card.caption}
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default GallerySection;
