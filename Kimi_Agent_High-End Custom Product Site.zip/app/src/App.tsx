import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
// Icons imported in individual components
import Navigation from './components/Navigation';
import HeroSection from './sections/HeroSection';
import GallerySection from './sections/GallerySection';
import FeaturedSection from './sections/FeaturedSection';
import BestsellersSection from './sections/BestsellersSection';
import NewDropSection from './sections/NewDropSection';
import AestheticSection from './sections/AestheticSection';
import StickerSection from './sections/StickerSection';
import PrintableSection from './sections/PrintableSection';
import NewsletterSection from './sections/NewsletterSection';

gsap.registerPlugin(ScrollTrigger);

function App() {
  const mainRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Wait for all sections to mount before setting up global snap
    const timer = setTimeout(() => {
      setupGlobalSnap();
    }, 500);

    return () => {
      clearTimeout(timer);
      ScrollTrigger.getAll().forEach(st => st.kill());
    };
  }, []);

  const setupGlobalSnap = () => {
    const pinned = ScrollTrigger.getAll()
      .filter(st => st.vars.pin)
      .sort((a, b) => a.start - b.start);
    
    const maxScroll = ScrollTrigger.maxScroll(window);
    if (!maxScroll || pinned.length === 0) return;

    const pinnedRanges = pinned.map(st => ({
      start: st.start / maxScroll,
      end: (st.end ?? st.start) / maxScroll,
      center: (st.start + ((st.end ?? st.start) - st.start) * 0.5) / maxScroll,
    }));

    ScrollTrigger.create({
      snap: {
        snapTo: (value: number) => {
          const inPinned = pinnedRanges.some(r => value >= r.start - 0.02 && value <= r.end + 0.02);
          if (!inPinned) return value;
          
          const target = pinnedRanges.reduce((closest, r) =>
            Math.abs(r.center - value) < Math.abs(closest - value) ? r.center : closest,
          pinnedRanges[0]?.center ?? 0);
          
          return target;
        },
        duration: { min: 0.15, max: 0.35 },
        delay: 0,
        ease: "power2.out"
      }
    });
  };

  return (
    <div ref={mainRef} className="relative bg-[#070A12]">
      {/* Grain Overlay */}
      <div className="grain-overlay" />
      
      {/* Navigation */}
      <Navigation />
      
      {/* Sections with z-index stacking */}
      <main className="relative">
        <HeroSection className="z-10" />
        <GallerySection className="z-20" />
        <FeaturedSection className="z-30" />
        <BestsellersSection className="z-40" />
        <NewDropSection className="z-50" />
        <AestheticSection className="z-[60]" />
        <StickerSection className="z-[70]" />
        <PrintableSection className="z-[80]" />
        <NewsletterSection className="z-[90]" />
      </main>
    </div>
  );
}

export default App;
