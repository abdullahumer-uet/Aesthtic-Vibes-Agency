import { useRef, useLayoutEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ArrowRight, Download, Zap } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

interface PrintableSectionProps {
  className?: string;
}

const PrintableSection = ({ className = '' }: PrintableSectionProps) => {
  const sectionRef = useRef<HTMLDivElement>(null);
  const cardRef = useRef<HTMLDivElement>(null);
  const imageRef = useRef<HTMLImageElement>(null);
  const headlineRef = useRef<HTMLHeadingElement>(null);
  const bodyRef = useRef<HTMLParagraphElement>(null);
  const ctaRef = useRef<HTMLDivElement>(null);
  const badgeRef = useRef<HTMLDivElement>(null);

  useLayoutEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const ctx = gsap.context(() => {
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: section,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.6,
        }
      });

      // ENTRANCE (0%-30%)
      scrollTl.fromTo(
        cardRef.current,
        { y: '100vh', rotateX: 45, scale: 0.88, opacity: 0 },
        { y: 0, rotateX: 0, scale: 1, opacity: 1, ease: 'none' },
        0
      );

      scrollTl.fromTo(
        headlineRef.current,
        { x: '-18vw', opacity: 0 },
        { x: 0, opacity: 1, ease: 'none' },
        0.1
      );

      scrollTl.fromTo(
        bodyRef.current,
        { y: 20, opacity: 0 },
        { y: 0, opacity: 1, ease: 'none' },
        0.15
      );

      scrollTl.fromTo(
        ctaRef.current,
        { y: 20, opacity: 0 },
        { y: 0, opacity: 1, ease: 'none' },
        0.2
      );

      scrollTl.fromTo(
        badgeRef.current,
        { scale: 0.8, opacity: 0 },
        { scale: 1, opacity: 1, ease: 'none' },
        0.25
      );

      // SETTLE (30%-70%): Hold with subtle parallax
      if (imageRef.current) {
        scrollTl.to(
          imageRef.current,
          { y: -12, ease: 'none' },
          0.3
        );
      }

      // EXIT (70%-100%)
      scrollTl.fromTo(
        cardRef.current,
        { y: 0, rotateX: 0, scale: 1, opacity: 1 },
        { y: '-30vh', rotateX: -14, scale: 0.96, opacity: 0, ease: 'power2.in' },
        0.70
      );

      scrollTl.fromTo(
        [headlineRef.current, bodyRef.current, ctaRef.current, badgeRef.current],
        { opacity: 1 },
        { opacity: 0, ease: 'power2.in' },
        0.75
      );
    }, section);

    return () => ctx.revert();
  }, []);

  return (
    <section 
      ref={sectionRef}
      id="printables"
      className={`section-pinned bg-[#070A12] ${className}`}
      style={{ perspective: '1200px' }}
    >
      <div className="relative w-full h-full flex items-center justify-center px-6 lg:px-0">
        {/* Wide Printable Card */}
        <div
          ref={cardRef}
          className="absolute left-[7vw] top-[14vh] w-[86vw] h-[72vh] ava-card will-change-transform overflow-hidden"
          style={{ transformStyle: 'preserve-3d' }}
        >
          <img
            src="/printable_art_setup.jpg"
            alt="Printable art"
            className="w-full h-full object-cover"
          />
          
          {/* Gradient overlay */}
          <div className="absolute inset-0 bg-gradient-to-r from-[#070A12]/95 via-[#070A12]/70 to-transparent" />
          
          {/* Content */}
          <div className="absolute inset-0 flex flex-col justify-center p-8 lg:p-16">
            <div className="max-w-lg">
              <div className="flex items-center gap-2 mb-4">
                <Download className="w-5 h-5 text-[#B9A0FF]" />
                <span className="font-mono text-sm text-[#B9A0FF] tracking-wider uppercase">Digital Downloads</span>
              </div>

              <h2
                ref={headlineRef}
                className="font-display text-4xl sm:text-5xl lg:text-6xl xl:text-7xl font-black text-[#F4F6FF] leading-tight mb-6"
              >
                PRINTABLE<br />ART
              </h2>

              <p
                ref={bodyRef}
                className="text-base lg:text-lg text-[#A7B0C8] mb-8 leading-relaxed"
              >
                Download high-res files instantly. Print at home, at a shop, or keep it digital. The fastest way to transform your space.
              </p>

              <div ref={ctaRef} className="flex items-center gap-4">
                <button className="btn-primary flex items-center gap-2">
                  Browse Printables
                  <ArrowRight className="w-4 h-4" />
                </button>
                <div
                  ref={badgeRef}
                  className="flex items-center gap-1 px-3 py-1.5 bg-[#B9A0FF]/20 text-[#B9A0FF] text-xs font-mono tracking-wider rounded-full"
                >
                  <Zap className="w-3 h-3" />
                  INSTANT DOWNLOAD
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default PrintableSection;
